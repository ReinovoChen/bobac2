#include "Aiuitest.h"
VoiceSemantic *ptr;

void change(string a,string b,bool c)
{
	if(ptr->ret_iat_str != NULL && ptr->ret_nlp_str != NULL){
		free(ptr->ret_iat_str);
		free(ptr->ret_nlp_str);
		ptr->ret_iat_str = NULL;
		ptr->ret_iat_str = NULL;
	}
	int len1 = a.length();
	int len2 = b.length();
	ptr->ret_iat_str = (char*)malloc(len1+1);
	ptr->ret_nlp_str = (char*)malloc(len2+1);
	memset(ptr->ret_iat_str,0,len1+1);
	memset(ptr->ret_nlp_str,0,len2+1);
	a.copy(ptr->ret_iat_str,len1,0);
	b.copy(ptr->ret_nlp_str,len2,0);
	
	ptr->ret_flag = c;
}

void VoiceListener::onEvent(const IAIUIEvent& event)const
{
	switch (event.getEventType()) {
	case AIUIConstant::EVENT_STATE:
		{
			switch (event.getArg1()) {
			case AIUIConstant::STATE_IDLE:
				{
					cout << "EVENT_STATE:" << "IDLE" << endl;
				} break;

			case AIUIConstant::STATE_READY:
				{
					cout << "EVENT_STATE:" << "READY" << endl;
				} break;

			case AIUIConstant::STATE_WORKING:
				{
					cout << "EVENT_STATE:" << "WORKING" << endl;
				} break;
			}
		} break;

	case AIUIConstant::EVENT_WAKEUP:
		{
			cout << "EVENT_WAKEUP:" << event.getInfo() << endl;
		} break;

	case AIUIConstant::EVENT_SLEEP:
		{
			cout << "EVENT_SLEEP:arg1=" << event.getArg1() << endl;
		} break;

	case AIUIConstant::EVENT_VAD:
		{
			ptr->ret_flag = false;	
			switch (event.getArg1()) {
			case AIUIConstant::VAD_BOS:
				{
					cout << "EVENT_VAD:" << "BOS" << endl;
				} break;

			case AIUIConstant::VAD_EOS:
				{
					cout << "EVENT_VAD:" << "EOS" << endl;
				} break;

			case AIUIConstant::VAD_VOL:
				{
					//						cout << "EVENT_VAD:" << "VOL" << endl;
				} break;
			}
		} break;

	case AIUIConstant::EVENT_RESULT:
		{
			Json::Value bizParamJson;
			Json::Reader reader;
			
			if (!reader.parse(event.getInfo(), bizParamJson, false)) {
				cout << "parse error!" << endl << event.getInfo() << endl;
				break;
			}
			Json::Value data = (bizParamJson["data"])[0];
			Json::Value params = data["params"];
			Json::Value content = (data["content"])[0];
			string sub = params["sub"].asString();
			cout << "EVENT_RESULT:" << sub << endl;

			if (sub == "nlp")
			{
				Json::Value empty;
				Json::Value contentId = content.get("cnt_id", empty);

				if (contentId.empty())
				{
					cout << "Content Id is empty" << endl;
					break;
				}

				string cnt_id = contentId.asString();
				Buffer* buffer = event.getData()->getBinary(cnt_id.c_str());
				string resultStr;

				if (NULL != buffer)
				{
					resultStr = string((char*)buffer->data());
					//cout << "============"<<resultStr << "========"<<endl;
					Json::Reader  ret_reader;
					Json::Value  ret_str;
					if(ret_reader.parse(resultStr,ret_str,false)){
						string iat_str = ret_str["intent"]["text"].asString();
						string nlp_str = ret_str["intent"]["answer"]["text"].asString();
						cout<<"<<<<<"<<iat_str<<">>>>>"<<endl;

						cout<<"-------------------------------------"<<endl;
						if(!nlp_str.empty()){
							cout<<"<<<<<"<<nlp_str<<">>>>>"<<endl;
						}else{
							cout<<"<<<<<不好意思，我没听懂。>>>>>"<<endl;
							nlp_str = "不好意思，我没听懂。";
						}

						change(iat_str,nlp_str,true);
					}else{
						cout<<"Result Read Error!!!"<<endl;
					}
				}
				else
				{
					cout << "buffer is NULL" << endl;
				}
			}

		}
		break;

	case AIUIConstant::EVENT_ERROR:
		{
			cout << "EVENT_ERROR:" << event.getArg1() << endl;
		} break;
	}



}

VoiceSemantic::VoiceSemantic()
{
	ret_iat_str = NULL;
	ret_nlp_str = NULL;
	ret_flag = false;
	magent = NULL;	
	w_flag = false;	
	AIUISetting::setAIUIDir(TEST_ROOT_DIR);
	AIUISetting::initLogger(LOG_DIR);
	agent_create();
	wakeup();
	ptr = this;
}

VoiceSemantic::~VoiceSemantic()
{
	if(ret_iat_str != NULL){
		free(ret_iat_str);
		ret_iat_str = NULL;
	}
	if(ret_nlp_str != NULL){
		free(ret_nlp_str);
		ret_nlp_str = NULL;
	}

	if (magent) {
		magent->destroy();
		magent = NULL;
	}

}


bool VoiceSemantic::voice_write(char* audio_file)
{
	string audio_path(audio_file);
	bool write_flag = false;
	mFileHelper = new FileUtil::DataFileHelper("");
	mFileHelper->openReadFile(audio_path, false);	


	while(!write_flag){	
		char audio[1279];
		int len = mFileHelper->read(audio, 1279);

		if (len > 0)
		{
			//cout << "len > 0" << endl;
			Buffer* buffer = Buffer::alloc(len);
			memcpy(buffer->data(), audio, len);

			IAIUIMessage * writeMsg = IAIUIMessage::create(AIUIConstant::CMD_WRITE,
					0, 0,  "data_type=audio,sample_rate=16000", buffer);	

			if (NULL != magent)
			{
				magent->sendMessage(writeMsg);
			}		
			writeMsg->destroy();
			usleep(10 * 1000);
		} else {
			//cout << "len < 0" << endl;
			IAIUIMessage * stopWrite = IAIUIMessage::create(AIUIConstant::CMD_STOP_WRITE,
					0, 0, "data_type=audio,sample_rate=16000");

			if (NULL != magent)
			{
				magent->sendMessage(stopWrite);
			}
			stopWrite->destroy();

			mFileHelper->closeReadFile();
			write_flag = true;
		}

	}
	return true;

}

void VoiceSemantic::agent_create()
{
	string appid = "5aab26ec";
	Json::Value paramJson;
	Json::Value appidJson;

	appidJson["appid"] = appid;
	string fileParam = FileUtil::readFileAsString(CFG_FILE_PATH);
	Json::Reader reader;
	if(reader.parse(fileParam, paramJson, false))
	{
		paramJson["login"] = appidJson;
		Json::FastWriter writer;
		string paramStr = writer.write(paramJson);
		magent = IAIUIAgent::createAgent(paramStr.c_str(), &listener);
	}
	
	else
	{
		cout << "aiui.cfg has something wrong!" << endl;
	}	


}

void VoiceSemantic::wakeup()
{
	if(NULL != magent){
		IAIUIMessage* wakeupMsg = IAIUIMessage::create(AIUIConstant::CMD_WAKEUP);
		magent->sendMessage(wakeupMsg);
		wakeupMsg->destroy();
	}
}
void VoiceSemantic::start()
{
	if(NULL != magent){
		IAIUIMessage * startMsg = IAIUIMessage::create (AIUIConstant::CMD_START);
		magent->sendMessage(startMsg);
		startMsg->destroy();
	}

}

void VoiceSemantic::stop()
{
	if (NULL != magent){
		IAIUIMessage *stopMsg = IAIUIMessage::create (AIUIConstant::CMD_STOP);
		magent->sendMessage(stopMsg);
		stopMsg->destroy();
	}

}
